#!/usr/bin/env python3
import os, shutil, struct, subprocess, sys
OUT_VTOY = 'Gdisk-Ventoy-Compressed.vtoy'
OUT_KRN  = 'Gdisk-Ventoy-Compressed.krn'
LEA_INSTR_OFFSET, LEA_DISP_OFFSET, LEA_INSTR_END_RVA = 0x6332, 0x6335, 0x6339
SIZE_LITERAL_OFFSET = 0x633e
EXPECTED_LEA_BYTES = bytes.fromhex('488d05173f0000')
EXPECTED_SIZE, EXPECTED_DATA_END, EXPECTED_RELOC_SIZE = 0x24d6f6, 0x257b60, 0x100
FILE_ALIGN = 0x20
OLD_MAGIC_OFFSET, OLD_MAGIC_END = 0xa250, 0xa270
OPT_SIZEOFINITDATA, OPT_SIZEOFIMAGE = 0x08, 0x38
OPT_DATADIR_BASE, DATADIR_BASERELOC = 0x70, 5
def align_up(v,a): return (v+a-1)&~(a-1)
def prompt(m,d=None):
    L=f'  {m}'+(f' [{d}]' if d else '')
    return input(f'{L}: ').strip() or d
def prompt_yn(m,dy=True):
    s='[Y/n]' if dy else '[y/N]'
    while True:
        v=input(f'  {m} {s}: ').strip().lower()
        if not v: return dy
        if v in ('y','yes'): return True
        if v in ('n','no'): return False
        print('  Please answer y or n')
def tiano_compress(t,s,o):
    sz0=os.path.getsize(s)
    print(f'[..] TianoCompress {os.path.basename(s)} ({sz0:,} bytes)')
    r=subprocess.run([t,'-e','--uefi','-o',o,s],capture_output=True,text=True)
    if r.returncode!=0: sys.exit(f'[!!] TianoCompress failed: {r.stderr}')
    sz=os.path.getsize(o)
    print(f'[OK] Compressed: {sz:,} bytes ({sz/1024/1024:.2f} MB, {sz*100/sz0:.1f}% of source)')
def patch_efi(sp,pp,mp,op):
    stock=bytearray(open(sp,'rb').read())
    payload=open(pp,'rb').read()
    magic=open(mp,'rb').read()
    assert len(magic)==32
    assert bytes(stock[LEA_INSTR_OFFSET:LEA_INSTR_OFFSET+7])==EXPECTED_LEA_BYTES
    assert struct.unpack('<I',stock[SIZE_LITERAL_OFFSET:SIZE_LITERAL_OFFSET+4])[0]==EXPECTED_SIZE
    pe_off=struct.unpack('<I',stock[0x3c:0x40])[0]
    coff_off=pe_off+4
    num=struct.unpack('<H',stock[coff_off+2:coff_off+4])[0]
    opt_size=struct.unpack('<H',stock[coff_off+0x10:coff_off+0x12])[0]
    opt_off=coff_off+0x14
    sect_off=opt_off+opt_size
    sections={}
    for i in range(num):
        s=sect_off+i*40
        sections[bytes(stock[s:s+8]).rstrip(b'\x00').decode()]=s
    new_array=magic+payload
    nsz=len(new_array)
    nrva=EXPECTED_DATA_END
    nde=align_up(nrva+nsz,FILE_ALIGN)
    nds=nde-0x9d60
    nrl=nde
    nim=nrl+EXPECTED_RELOC_SIZE
    nld=nrva-LEA_INSTR_END_RVA
    out=bytearray(stock[:EXPECTED_DATA_END])+bytearray(new_array)
    while len(out)<nde: out.append(0)
    out+=stock[EXPECTED_DATA_END:EXPECTED_DATA_END+EXPECTED_RELOC_SIZE]
    out[LEA_DISP_OFFSET:LEA_DISP_OFFSET+4]=struct.pack('<i',nld)
    out[SIZE_LITERAL_OFFSET:SIZE_LITERAL_OFFSET+4]=struct.pack('<I',nsz)
    out[OLD_MAGIC_OFFSET:OLD_MAGIC_END]=bytes(32)
    out[opt_off+OPT_SIZEOFIMAGE:opt_off+OPT_SIZEOFIMAGE+4]=struct.pack('<I',nim)
    out[opt_off+OPT_SIZEOFINITDATA:opt_off+OPT_SIZEOFINITDATA+4]=struct.pack('<I',nds+EXPECTED_RELOC_SIZE)
    dd5=opt_off+OPT_DATADIR_BASE+DATADIR_BASERELOC*8
    out[dd5:dd5+4]=struct.pack('<I',nrl)
    ds=sections['.data']
    out[ds+0x08:ds+0x0c]=struct.pack('<I',nds)
    out[ds+0x10:ds+0x14]=struct.pack('<I',nds)
    rs=sections['.reloc']
    out[rs+0x0c:rs+0x10]=struct.pack('<I',nrl)
    out[rs+0x14:rs+0x18]=struct.pack('<I',nrl)
    open(op,'wb').write(bytes(out))
    return len(out),nsz
def main():
    if len(sys.argv)!=2: sys.exit('Usage: gdiskchain_build.py <bundle_dir>')
    b=sys.argv[1]
    stock=os.path.join(b,'vdiskchain.efi'); tiano=os.path.join(b,'TianoCompress')
    magic=os.path.join(b,'magic.bin'); ipxe=os.path.join(b,'ipxe.krn')
    for p in (stock,tiano,magic,ipxe):
        if not os.path.isfile(p): sys.exit(f'[!!] Bundle file missing: {p}')
    print(); print('='*60); print('  Gdisk Ventoy Compressor'); print('='*60); print()
    print('  Builds a tianocompressed grub-bootable Ventoy (UEFI + BIOS).'); print()
    while True:
        src=prompt('Path to source Ventoy .img file')
        if not src: print('  (no path entered)'); continue
        src=os.path.expanduser(src)
        if not os.path.isfile(src): print(f'  File not found: {src}'); continue
        break
    src_size=os.path.getsize(src)
    print(f'[OK] Source: {src} ({src_size:,} bytes / {src_size/1024/1024:.2f} MB)')
    sd=os.path.dirname(os.path.abspath(src))
    out_vtoy=os.path.join(sd,OUT_VTOY); out_krn=os.path.join(sd,OUT_KRN)
    ex=[p for p in (out_vtoy,out_krn) if os.path.exists(p)]
    if ex:
        print(); print('[!!] Output file(s) already exist:')
        for p in ex: print(f'     {p}')
        if not prompt_yn('Overwrite',True): print('[--] Aborted by user'); sys.exit(0)
    print(); print('-'*60)
    payload=os.path.join(b,'payload.bin')
    tiano_compress(tiano,src,payload)
    print(f'[..] Patching vdiskchain.efi with new payload')
    osz,asz=patch_efi(stock,payload,magic,out_vtoy)
    print(f'[OK] Wrote {OUT_VTOY}'); print(f'     {osz:,} bytes ({osz/1024/1024:.2f} MB)')
    shutil.copy2(ipxe,out_krn)
    ksz=os.path.getsize(out_krn)
    print(f'[OK] Wrote {OUT_KRN}'); print(f'     {ksz:,} bytes (patched iPXE BIOS shim)')
    print(); print('-'*60); print(f'Output directory: {sd}'); print()
    print('Sample grub menuentries (UEFI needs vdisk= self-reference,'); print('BIOS does NOT - bundled ipxe.krn is patched):')
    print()
    print('  menuentry "Gdisk Ventoy (UEFI)" {')
    print('      insmod chain')
    print(f'      chainloader /path/to/{OUT_VTOY} vdisk={OUT_VTOY}')
    print('  }'); print()
    print('  menuentry "Gdisk Ventoy (BIOS)" {')
    print(f'      linux16  /path/to/{OUT_KRN}')
    print(f'      initrd16 /path/to/{OUT_VTOY}')
    print('  }'); print()
if __name__=='__main__':
    try: main()
    except KeyboardInterrupt: print(); sys.exit(130)
